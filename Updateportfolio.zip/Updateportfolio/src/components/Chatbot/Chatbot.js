import React, { useState, useRef, useEffect } from 'react';
import { FaComments, FaTimes, FaPaperPlane } from 'react-icons/fa';
import './Chatbot.css';

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hi! I'm Praveen's AI assistant. Ask me anything about his skills, projects, or experience! 👋",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  // Predefined Q&A data
  const qnaData = [
    {
      keywords: ['who are you', 'who is praveen', 'about you', 'introduce yourself'],
      answer: "I'm Praveen, a Software Engineer specializing in Frontend Development using React, Redux, and React Native."
    },
    {
      keywords: ['technologies', 'skills', 'tech stack', 'what do you know', 'programming languages'],
      answer: "💻 Frontend: React.js (Hooks, Context, Redux, Zustand), JavaScript (ES6+), TypeScript (in progress), HTML5, CSS3, Tailwind CSS, Bootstrap, Responsive Design, Form Handling (Formik)\n\n📱 Mobile & UI: React Native, UI/UX basics (Figma, wireframing)\n\n⚙️ Backend & API: .NET Core (Web API, MVC), REST API Integration, SignalR\n\n☁️ Cloud: AWS S3, CloudFront, exploring AI Services\n\n🛠️ Tools: Git, GitHub, NPM, Yarn, Postman, VS Code\n\n🤖 AI Tools: Cursor, Augment, ChatGPT, GitHub Copilot\n\n🌐 CMS: WordPress (Custom Themes & Plugins, SEO)"
    },
    {
      keywords: ['backend', 'server', 'database', 'api'],
      answer: "I have trained in Full-Stack Development with .NET and have basic hands-on with APIs and databases. Currently, I'm focused on React and learning cloud (AWS)."
    },
    {
      keywords: ['cloud', 'aws', 'amazon', 'hosting'],
      answer: "I'm currently learning AWS cloud services. I have hands-on experience with AWS S3 for static hosting and AWS CloudFront for CDN and HTTPS. I'm actively exploring AWS AI Services like Textract, Rekognition, and Lex for future projects."
    },
    {
      keywords: ['projects', 'work', 'portfolio', 'built', 'developed'],
      answer: "Sure! I've built:\n• A Healthcare Management System with React + Zustand + SignalR for real-time communication.\n• A Real Estate Contract App with React + Formik + SignalR for contracts and chats.\n• A Text Detector App using React Native + expo-camera + REST API for OCR.\n• Several WordPress customizations with plugins/themes for SEO optimization."
    },
    {
      keywords: ['proud', 'favorite project', 'best project', 'most proud'],
      answer: "The Healthcare Management System — it had multiple portals (Admin, Doctor, Patient), integrated video consultation, and API-driven e-prescriptions."
    },
    {
      keywords: ['current role', 'job', 'work', 'company', 'position'],
      answer: "I'm working as a Software Engineer at Creators Infotek, focusing on React-based frontend development."
    },
    {
      keywords: ['experience', 'years', 'how long', 'professional'],
      answer: "I have 2+ years of professional experience in frontend development."
    },
    {
      keywords: ['contact', 'email', 'reach', 'linkedin', 'connect'],
      answer: "You can reach me via email at saiprawin0466@gmail.com or connect with me on LinkedIn: https://linkedin.com/in/praveen-r-20536324b"
    },
    {
      keywords: ['resume', 'cv', 'download'],
      answer: "Yes! You can download my resume directly from this portfolio using the Resume section in the navigation menu."
    },
    {
      keywords: ['hello', 'hi', 'hey', 'greetings'],
      answer: "Hello! Great to meet you! I'm here to answer any questions about Praveen's skills, experience, and projects. What would you like to know?"
    },
    {
      keywords: ['thank', 'thanks', 'appreciate'],
      answer: "You're welcome! Feel free to ask me anything else about Praveen's work or experience. I'm here to help! 😊"
    }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const findAnswer = (question) => {
    const lowerQuestion = question.toLowerCase();
    
    for (const qa of qnaData) {
      if (qa.keywords.some(keyword => lowerQuestion.includes(keyword))) {
        return qa.answer;
      }
    }
    
    return "Sorry, I don't know that yet. You can try asking about Praveen's skills, projects, experience, or contact information!";
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse = {
        id: Date.now() + 1,
        text: findAnswer(inputText),
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div style={{
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      zIndex: 1000
    }}>
      {/* Chat Toggle Button */}
      {!isOpen && (
        <button
          onClick={toggleChat}
          style={{
            backgroundColor: '#cd5ff8',
            color: 'white',
            padding: '16px',
            borderRadius: '50%',
            border: 'none',
            boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            fontSize: '24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#b854d4';
            e.target.style.transform = 'scale(1.1)';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#cd5ff8';
            e.target.style.transform = 'scale(1)';
          }}
        >
          <FaComments size={24} />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
          width: '320px',
          height: '400px',
          display: 'flex',
          flexDirection: 'column',
          border: '1px solid #e5e7eb'
        }}>
          {/* Header */}
          <div style={{
            backgroundColor: '#cd5ff8',
            color: 'white',
            padding: '16px',
            borderTopLeftRadius: '12px',
            borderTopRightRadius: '12px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div>
              <h3 style={{ margin: 0, fontWeight: '600', fontSize: '16px' }}>Chat with Praveen's AI</h3>
              <p style={{ margin: 0, fontSize: '14px', opacity: 0.9 }}>Ask me anything!</p>
            </div>
            <button
              onClick={toggleChat}
              style={{
                backgroundColor: 'transparent',
                border: 'none',
                color: 'white',
                padding: '4px',
                borderRadius: '4px',
                cursor: 'pointer',
                transition: 'background-color 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.backgroundColor = '#b854d4'}
              onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
            >
              <FaTimes size={16} />
            </button>
          </div>

          {/* Messages Area */}
          <div className="chatbot-messages" style={{
            flex: 1,
            overflowY: 'auto',
            padding: '16px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px'
          }}>
            {messages.map((message) => (
              <div
                key={message.id}
                style={{
                  display: 'flex',
                  justifyContent: message.isBot ? 'flex-start' : 'flex-end'
                }}
              >
                <div
                  style={{
                    maxWidth: '240px',
                    padding: '8px 12px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    backgroundColor: message.isBot ? '#f3f4f6' : '#cd5ff8',
                    color: message.isBot ? '#374151' : 'white',
                    whiteSpace: 'pre-line'
                  }}
                >
                  {message.text}
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                <div style={{
                  backgroundColor: '#f3f4f6',
                  color: '#374151',
                  padding: '8px 12px',
                  borderRadius: '12px',
                  fontSize: '14px'
                }}>
                  <div style={{ display: 'flex', gap: '4px' }}>
                    <div className="typing-dot"></div>
                    <div className="typing-dot" style={{ animationDelay: '0.1s' }}></div>
                    <div className="typing-dot" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div style={{
            padding: '16px',
            borderTop: '1px solid #e5e7eb'
          }}>
            <div style={{ display: 'flex', gap: '8px' }}>
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your question..."
                style={{
                  flex: 1,
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  padding: '8px 12px',
                  fontSize: '14px',
                  outline: 'none'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#cd5ff8';
                  e.target.style.boxShadow = '0 0 0 2px rgba(205, 95, 248, 0.2)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = '#d1d5db';
                  e.target.style.boxShadow = 'none';
                }}
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputText.trim()}
                style={{
                  backgroundColor: inputText.trim() ? '#cd5ff8' : '#d1d5db',
                  color: 'white',
                  padding: '8px',
                  borderRadius: '8px',
                  border: 'none',
                  cursor: inputText.trim() ? 'pointer' : 'not-allowed',
                  transition: 'background-color 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                onMouseEnter={(e) => {
                  if (inputText.trim()) {
                    e.target.style.backgroundColor = '#b854d4';
                  }
                }}
                onMouseLeave={(e) => {
                  if (inputText.trim()) {
                    e.target.style.backgroundColor = '#cd5ff8';
                  }
                }}
              >
                <FaPaperPlane size={14} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
