import React, { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Particle from "../Particle";
import pdf from "../../Assets/Praveenupdated-resume.pdf";
import { AiOutlineDownload, AiOutlineEye, AiOutlineFileText } from "react-icons/ai";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/esm/Page/AnnotationLayer.css";
import "react-pdf/dist/esm/Page/TextLayer.css";

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

function ResumeNew() {
  const [width, setWidth] = useState(1200);

  useEffect(() => {
    setWidth(window.innerWidth);
  }, []);

  return (
    <div>
      <Container fluid className="resume-section">
        <Particle />

        {/* Header Section */}
        <Container>
          <Row style={{ justifyContent: "center", paddingBottom: "20px" }}>
            <Col md={8} className="text-center">
              <h1 className="project-heading" style={{ paddingBottom: "20px" }}>
                My <strong className="purple">Resume</strong>
              </h1>
              <p style={{
                color: "white",
                fontSize: "1.1em",
                paddingBottom: "30px",
                lineHeight: "1.6"
              }}>
                Download my resume to get a detailed overview of my professional experience,
                technical skills, and educational background.
              </p>
            </Col>
          </Row>

          {/* Download Button Section */}
          <Row style={{ justifyContent: "center", paddingBottom: "40px" }}>
            <Col md={6} lg={4} className="text-center">
              <div style={{
                background: "rgba(255, 255, 255, 0.05)",
                borderRadius: "15px",
                padding: "30px 20px",
                border: "1px solid rgba(199, 112, 240, 0.3)",
                backdropFilter: "blur(10px)"
              }}>
                <AiOutlineFileText
                  size={50}
                  className="purple"
                  style={{ marginBottom: "20px" }}
                />
                <h4 className="purple" style={{ marginBottom: "15px" }}>
                  Professional Resume
                </h4>
                <p style={{
                  color: "rgba(255, 255, 255, 0.8)",
                  fontSize: "0.95em",
                  marginBottom: "25px"
                }}>
                  2+ years of Frontend Development experience
                </p>
                <Button
                  variant="primary"
                  href={pdf}
                  target="_blank"
                  style={{
                    padding: "12px 30px",
                    fontSize: "1.1em",
                    borderRadius: "25px",
                    border: "none",
                    background: "linear-gradient(45deg, #623686, #c770f0)",
                    transition: "all 0.3s ease",
                    boxShadow: "0 4px 15px rgba(199, 112, 240, 0.3)"
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.transform = "translateY(-2px)";
                    e.target.style.boxShadow = "0 6px 20px rgba(199, 112, 240, 0.4)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.transform = "translateY(0)";
                    e.target.style.boxShadow = "0 4px 15px rgba(199, 112, 240, 0.3)";
                  }}
                >
                  <AiOutlineDownload style={{ marginRight: "8px" }} />
                  Download Resume
                </Button>
              </div>
            </Col>
          </Row>
        </Container>

        {/* PDF Preview Section */}
        <Container>
          <Row style={{ justifyContent: "center", paddingBottom: "30px" }}>
            <Col md={10} lg={8} className="text-center">
              <h3 className="purple" style={{ marginBottom: "30px" }}>
                <AiOutlineEye style={{ marginRight: "10px" }} />
                Preview
              </h3>
              <div style={{
                background: "rgba(255, 255, 255, 0.03)",
                borderRadius: "20px",
                padding: "30px",
                border: "1px solid rgba(199, 112, 240, 0.2)",
                boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)"
              }}>
                <Document
                  file={pdf}
                  className="d-flex justify-content-center"
                  loading={
                    <div style={{
                      color: "white",
                      padding: "50px",
                      textAlign: "center"
                    }}>
                      <div className="purple" style={{ fontSize: "1.2em" }}>
                        Loading Resume...
                      </div>
                    </div>
                  }
                  error={
                    <div style={{
                      color: "white",
                      padding: "50px",
                      textAlign: "center"
                    }}>
                      <div style={{ color: "#ff6b6b", fontSize: "1.2em" }}>
                        Failed to load PDF. Please try downloading instead.
                      </div>
                    </div>
                  }
                >
                  <Page
                    pageNumber={1}
                    scale={width > 786 ? 1.4 : 0.7}
                    renderTextLayer={false}
                    renderAnnotationLayer={false}
                  />
                </Document>
              </div>
            </Col>
          </Row>

          {/* Bottom Download Section */}
          <Row style={{ justifyContent: "center", paddingBottom: "50px" }}>
            <Col md={6} className="text-center">
              <p style={{
                color: "rgba(255, 255, 255, 0.7)",
                marginBottom: "20px",
                fontSize: "0.95em"
              }}>
                Like what you see? Download the full resume for more details.
              </p>
              <Button
                variant="primary"
                href={pdf}
                target="_blank"
                style={{
                  padding: "10px 25px",
                  borderRadius: "20px",
                  border: "2px solid #c770f0",
                  background: "transparent",
                  color: "#c770f0",
                  transition: "all 0.3s ease"
                }}
                onMouseEnter={(e) => {
                  e.target.style.background = "#c770f0";
                  e.target.style.color = "white";
                  e.target.style.transform = "translateY(-1px)";
                }}
                onMouseLeave={(e) => {
                  e.target.style.background = "transparent";
                  e.target.style.color = "#c770f0";
                  e.target.style.transform = "translateY(0)";
                }}
              >
                <AiOutlineDownload style={{ marginRight: "8px" }} />
                Download Resume
              </Button>
            </Col>
          </Row>
        </Container>
      </Container>
    </div>
  );
}

export default ResumeNew;
