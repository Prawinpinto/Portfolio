import React from "react";
import { Col, Row } from "react-bootstrap";
import {
  DiJavascript1,
  DiReact,
  DiHtml5,
  DiCss3,
  DiBootstrap,
  DiDotnet,
  DiWordpress,
  DiGit,
} from "react-icons/di";
import {
  SiTypescript,
  SiTailwindcss,
  SiRedux,
  SiAmazonaws,
  SiPostman,
  SiFigma,
} from "react-icons/si";
import { FaMobile, FaCloud, FaWpforms, FaSignal } from "react-icons/fa";
import { TbBrandReactNative } from "react-icons/tb";

function Techstack() {
  return (
    <div>
      {/* Frontend Skills */}
      <h3 className="purple" style={{ textAlign: "center", marginBottom: "30px" }}>
        Frontend
      </h3>
      <Row style={{ justifyContent: "center", paddingBottom: "30px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <DiReact />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>React.js</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <DiJavascript1 />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>JavaScript</p>
        </Col>
       
        <Col xs={4} md={2} className="tech-icons">
          <DiHtml5 />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>HTML5</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <DiCss3 />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>CSS3</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiTailwindcss />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Tailwind</p>
        </Col>
      </Row>

      <Row style={{ justifyContent: "center", paddingBottom: "40px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <DiBootstrap />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Bootstrap</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiRedux />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Redux</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <FaWpforms />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Formik</p>
        </Col>
      </Row>

      {/* Mobile & UI */}
      <h3 className="purple" style={{ textAlign: "center", marginBottom: "30px" }}>
       Mobile & UI
      </h3>
      <Row style={{ justifyContent: "center", paddingBottom: "40px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <TbBrandReactNative />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>React Native</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiFigma />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Figma</p>
        </Col>
      </Row>

      {/* Backend & API */}
      <h3 className="purple" style={{ textAlign: "center", marginBottom: "30px" }}>
         Backend & API
      </h3>
      <Row style={{ justifyContent: "center", paddingBottom: "40px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <DiDotnet />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>.NET Core</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <FaSignal />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>SignalR</p>
        </Col>
      </Row>

      {/* Cloud */}
      <h3 className="purple" style={{ textAlign: "center", marginBottom: "30px" }}>
       Cloud
      </h3>
      <Row style={{ justifyContent: "center", paddingBottom: "40px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <SiAmazonaws />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>AWS</p>
        </Col>
      </Row>

      {/* CMS */}
      <h3 className="purple" style={{ textAlign: "center", marginBottom: "30px" }}>
         CMS
      </h3>
      <Row style={{ justifyContent: "center", paddingBottom: "50px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <DiWordpress />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>WordPress</p>
        </Col>
      </Row>
    </div>
  );
}

export default Techstack;
