import React from "react";
import { Col, Row } from "react-bootstrap";
import {
  SiVisualstudiocode,
  SiPostman,
  SiGit,
  SiGithub,
  SiNpm,
  SiYarn,
  SiOpenai,
} from "react-icons/si";
import { DiGit } from "react-icons/di";
import { FaRobot, FaBrain, FaMousePointer } from "react-icons/fa";

function Toolstack() {
  return (
    <div>
      {/* Development Tools */}
    
      <Row style={{ justifyContent: "center", paddingBottom: "40px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <DiGit />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Git</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiGithub />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>GitHub</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiNpm />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>NPM</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiYarn />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Yarn</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiPostman />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Postman</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiVisualstudiocode />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>VS Code</p>
        </Col>
      </Row>

      {/* AI-Powered Development Tools */}
      <h3 className="purple" style={{ textAlign: "center", marginBottom: "30px" }}>
         AI-Powered Development Tools
      </h3>
      <Row style={{ justifyContent: "center", paddingBottom: "50px" }}>
        <Col xs={4} md={2} className="tech-icons">
          <FaMousePointer />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Cursor</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <FaBrain />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Augment</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <SiOpenai />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>ChatGPT</p>
        </Col>
        <Col xs={4} md={2} className="tech-icons">
          <FaRobot />
          <p style={{ fontSize: "14px", marginTop: "10px" }}>Copilot</p>
        </Col>
      </Row>
    </div>
  );
}

export default Toolstack;
